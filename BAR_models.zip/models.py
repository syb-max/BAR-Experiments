"""Scorer models. Qwen2 numerical embeddings follow Sec. II-E; the
candidate-conditioned residual head is explicitly an engineering reconstruction.
"""
import torch
from torch import nn


class MLPEncoder(nn.Module):
    def __init__(self, feature_dim, hidden=96):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(feature_dim,256),nn.GELU(),
                                 nn.Linear(256,hidden),nn.GELU())
        self.out_dim = hidden
    def forward(self,x): return self.net(x)


class CNNEncoder(nn.Module):
    def __init__(self, feature_dim, hidden=96):
        super().__init__()
        self.conv = nn.Sequential(nn.Conv1d(1,32,5,padding=2),nn.GELU(),
                                  nn.Conv1d(32,64,5,padding=2),nn.GELU(),
                                  nn.AdaptiveAvgPool1d(8))
        self.fc = nn.Linear(64*8,hidden)
        self.out_dim = hidden
    def forward(self,x): return self.fc(self.conv(x[:,None,:]).flatten(1))


class SmallTransformerEncoder(nn.Module):
    def __init__(self, feature_dim, hidden=96):
        super().__init__()
        self.proj=nn.Linear(1,hidden)
        self.pos=nn.Parameter(torch.zeros(1,feature_dim,hidden))
        layer=nn.TransformerEncoderLayer(hidden,4,hidden*2,dropout=0.1,
                                         batch_first=True,activation='gelu')
        self.net=nn.TransformerEncoder(layer,2,enable_nested_tensor=False)
        self.out_dim=hidden
    def forward(self,x): return self.net(self.proj(x[...,None])+self.pos).mean(1)


class Q2NumericalEncoder(nn.Module):
    """Qwen2-0.5B; each scalar projected to model hidden dim and sent by inputs_embeds.
    `frozen`, `full`, and `last4` are paper's adaptation names.
    Requires locally available checkpoint or permitted Hugging Face download.
    """
    def __init__(self, feature_dim, mode='last4', model_name='Qwen/Qwen2-0.5B'):
        super().__init__()
        try:
            from transformers import AutoModel
        except ImportError as exc:
            raise RuntimeError('Install pip install -e ".[qwen]" for Q2 model') from exc
        self.backbone = AutoModel.from_pretrained(model_name, trust_remote_code=False)
        h=self.backbone.config.hidden_size
        self.numeric_projection=nn.Linear(1,h)
        self.out_dim=h
        for p in self.backbone.parameters(): p.requires_grad_(mode=='full')
        if mode=='last4':
            # For Qwen2Model, layers is exposed as .layers.
            layers=getattr(self.backbone,'layers',None)
            if layers is None: raise RuntimeError('Expected Qwen2Model.layers; check transformers model class')
            for block in layers[-4:]:
                for p in block.parameters(): p.requires_grad_(True)
        elif mode not in ('full','frozen'):
            raise ValueError(mode)
        self.mode=mode

    def forward(self,x):
        emb=self.numeric_projection(x[...,None])
        out=self.backbone(inputs_embeds=emb, use_cache=False, return_dict=True)
        return out.last_hidden_state.mean(dim=1)


class CandidateScorer(nn.Module):
    """Candidate output: normalized norm prior + learned score correction.

    Paper specifies the 128-d scene encoding, mean pooling and residual head,
    but NOT the candidate-specific head wiring. The descriptor head below is an
    explicitly documented replacement compatible with large candidate spaces.
    """
    def __init__(self, feature_dim, candidate_dim, backbone='mlp', mode='last4',
                 qwen_checkpoint='Qwen/Qwen2-0.5B', hidden=96):
        super().__init__()
        if backbone=='mlp': enc=MLPEncoder(feature_dim,hidden)
        elif backbone=='cnn': enc=CNNEncoder(feature_dim,hidden)
        elif backbone=='transformer': enc=SmallTransformerEncoder(feature_dim,hidden)
        elif backbone=='q2': enc=Q2NumericalEncoder(feature_dim,mode,qwen_checkpoint)
        else: raise ValueError(backbone)
        self.encoder=enc
        self.scene_head=nn.Sequential(nn.Linear(enc.out_dim,hidden),nn.GELU())
        self.cand_head=nn.Sequential(nn.Linear(candidate_dim,hidden),nn.GELU())
        self.residual=nn.Sequential(nn.Linear(hidden*3,hidden),nn.GELU(),nn.Linear(hidden,1))
        self.backbone_name=backbone

    def encode(self,x): return self.scene_head(self.encoder(x))

    def score_chunk(self,ctx,masks,prior=None,correction_only=False):
        """ctx:[batch,H], masks:[N,D] or [batch,N,D], prior:[batch,N]."""
        if masks.ndim==2:
            cand=self.cand_head(masks)[None,:,:].expand(ctx.shape[0],-1,-1)
        else: cand=self.cand_head(masks)
        scene=ctx[:,None,:].expand(-1,cand.shape[1],-1)
        fused=torch.cat((scene,cand,scene*cand),dim=-1)
        corr=self.residual(fused).squeeze(-1)
        return corr if correction_only else (corr if prior is None else prior+corr)

    def forward(self,x,masks,prior=None,correction_only=False):
        return self.score_chunk(self.encode(x),masks,prior,correction_only)


def make_scorer(feature_dim,candidate_dim,backbone,mode='last4',qwen_checkpoint='Qwen/Qwen2-0.5B'):
    return CandidateScorer(feature_dim,candidate_dim,backbone,mode,qwen_checkpoint)
